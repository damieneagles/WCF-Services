﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.ServiceModel;
using System.Text;
using System.Threading.Tasks;

namespace _SelfHostingApplication_WindowsOnly_
{
    /// <summary>
    /// [Copyright 2025 on all intellectual property by [Damien Wallace Eagles] eternally]
    /// </summary>
    internal class Program
    {
        static void Main(string[] args)
        {
            Uri[] baseAddresses = new Uri[]
            {
                new Uri("http://localhost:10001"),
                new Uri("net.tcp://localhost:10002")
            };

            MyCustomServiceHost host = new MyCustomServiceHost(typeof(CalculatorServices.MyCalculatorService), baseAddresses);
            host.AddDefaultEndpoints();

            try
            {
                host.Open();
                Console.WriteLine("MyCalculatorService is now listening on the end points\n");
                foreach (var endpoint in host.Description.Endpoints)
                {
                    Console.WriteLine("\t" + endpoint.Address.Uri.ToString());
                }
                Console.ReadLine();
                host.Close();
            }
            catch (CommunicationException cex)
            {
                Console.Write("ERROR - " + cex.ToString());
                Console.ReadLine();
                host.Abort();
            }
            catch (TimeoutException tex)
            {
                Console.Write("ERROR - " + tex.ToString());
                Console.ReadLine();
                host.Abort();
            }
            catch (Exception ex)
            {
                Console.Write("ERROR - " + ex.ToString());
                Console.ReadLine();
                host.Abort();
                throw;
            }

        }
    }
}
