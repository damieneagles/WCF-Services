﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.CompilerServices;
using System.ServiceModel;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace _SelfHostingApplication_WindowsOnly_
{
    /// <summary>
    /// [Copyright 2025 on all intellectual property by [Damien Wallace Eagles] eternally whereever it goes no matter what - - - - ]
    /// </summary>
    internal class Program
    {
        static void Main(string[] args)
        {
            var tokenSource1 = new CancellationTokenSource();
            var token1 = tokenSource1.Token;

            var t1 = Task.Factory.StartNew(() => 
            {
                
                    Uri[] baseAddresses1 = new Uri[]
                    {
                    new Uri("http://localhost:10001"),
                    new Uri("net.tcp://localhost:10002")
                    };

                    MyCustomServiceHost host1 = new MyCustomServiceHost(typeof(CalculatorServices_1_0.MyCalculatorService), baseAddresses1);
                    StringBuilder sb = new StringBuilder();

                    host1.AddDefaultEndpoints();

                    try
                    {
                        host1.Open();
                        sb.Append("MyCalculatorService Version 1.0 is now listening on the end points\n");
                        foreach (var endpoint in host1.Description.Endpoints)
                        {
                            sb.Append("\t" + endpoint.Address.Uri.ToString() + "\n");
                        }
                        sb.Append("Press any key to continue...\n");

                        Console.WriteLine(sb.ToString());
                        Console.ReadLine();
                        host1.Close();
                    }
                    catch (CommunicationException cex)
                    {
                        Console.WriteLine("ERROR - " + cex.ToString());
                        Console.ReadLine();
                        host1.Abort();
                    }
                    catch (TimeoutException tex)
                    {
                        Console.WriteLine("ERROR - " + tex.ToString());
                        Console.ReadLine();
                        host1.Abort();
                    }
                    catch (Exception ex)
                    {
                        Console.WriteLine("ERROR - " + ex.ToString());
                        Console.ReadLine();
                        host1.Abort();
                        throw;
                    }
            }, token1);

            var tokenSource2 = new CancellationTokenSource();
            var token2 = tokenSource2.Token;

            var t2 = Task.Factory.StartNew(() =>
            {
                Uri[] baseAddresses2 = new Uri[]
                {
                        new Uri("http://localhost:10010"),
                        new Uri("net.tcp://localhost:10011")
                };

                MyCustomServiceHost host2 = new MyCustomServiceHost(typeof(CalculatorServices_1_1.MyCalculatorService), baseAddresses2);
                StringBuilder sb = new StringBuilder();

                host2.AddDefaultEndpoints();

                try
                {
                    host2.Open();
                    sb.Append("MyCalculatorService Version 1.1 is now listening on the end points\n");
                    foreach (var endpoint in host2.Description.Endpoints)
                    {
                        sb.Append("\t" + endpoint.Address.Uri.ToString()+"\n");
                    }
                    sb.Append("Press any key to continue...\n");
                    Console.WriteLine(sb.ToString());
                    Console.ReadLine();
                    host2.Close();
                }
                catch (CommunicationException cex)
                {
                    Console.WriteLine("ERROR - " + cex.ToString());
                    Console.ReadLine();
                    host2.Abort();
                }
                catch (TimeoutException tex)
                {
                    Console.WriteLine("ERROR - " + tex.ToString());
                    Console.ReadLine();
                    host2.Abort();
                }
                catch (Exception ex)
                {
                    Console.WriteLine("ERROR - " + ex.ToString());
                    Console.ReadLine();
                    host2.Abort();
                    throw;
                }
            }, token2);

            Task.WaitAll(new Task[] { t1, t2 });
        }
    }
}
