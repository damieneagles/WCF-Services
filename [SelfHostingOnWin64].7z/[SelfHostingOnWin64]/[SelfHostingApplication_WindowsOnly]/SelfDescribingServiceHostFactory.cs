﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.ServiceModel;
using System.ServiceModel.Channels;
using System.ServiceModel.Activation;
using System.ServiceModel.Description;
using System.Web;

namespace _SelfHostingApplication_WindowsOnly_
{
    /// <summary>
    /// [Copyright 2025 on all intellectual property by [Damien Wallace Eagles] eternally]
    /// </summary>
    internal class SelfDescribingServiceHostFactory : ServiceHostFactoryBase
    {
        
        public override ServiceHostBase CreateServiceHost(string constructorString, Uri[] baseAddresses)
        {
            //this.ApplyConfiguration();
            return this.CreateServiceHost(constructorString, baseAddresses);

            foreach (Uri baseAddress in baseAddresses)
            {
                {
                    this.AddServiceEndpoint(ServiceMetadataBehavior.MexContractName,
                                            MetadataExchangeBindings.CreateMexHttpBinding(),
                                            "mex");

                }
                else if (baseAddress.Scheme == Uri.UriSchemeHttps)
                {
                    mexBehavior.HttpGetEnabled = true;
                    this.AddServiceEndpoint(ServiceMetadataBehavior.MexContractName,
                                            MetadataExchangeBindings.CreateMexHttpsBinding(),
                                            "mex");
                }
                else if (baseAddress.Scheme == Uri.UriSchemeNetPipe)
                {
                    mexBehavior.HttpGetEnabled = true;
                    this.AddServiceEndpoint(ServiceMetadataBehavior.MexContractName,
                                            MetadataExchangeBindings.CreateMexNamedPipeBinding(),
                                            "mex");

                }
                else if (baseAddress.Scheme == Uri.UriSchemeNetTcp)
                {
                    mexBehavior.HttpGetEnabled = true;
                    this.AddServiceEndpoint(ServiceMetadataBehavior.MexContractName,
                                            MetadataExchangeBindings.CreateMexTcpBinding(),
                                            "mex");
                }


            }
        }
    }
}