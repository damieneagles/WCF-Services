﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.ServiceModel;
using System.ServiceModel.Channels;
using System.ServiceModel.Description;
using System.Web;

namespace _SelfHostingApplication_WindowsOnly_
{
    /// <summary>
    /// [Copyright 2025 on all intellectual property by [Damien Wallace Eagles] eternally whereever it goes no matter what - - - - ]
    /// NOTE Remember - "netsh http add urlacl url=http://+:10001/ user=DOMAIN\User"
    /// NOTE Remember - "netsh http add urlacl url=http://+:10002/ user=DOMAIN\User"
    /// </summary>
    public class MyCustomServiceHost : ServiceHost
    {
        private Uri[] baseAddresses = new Uri[0];
        public MyCustomServiceHost(Type servicetype, Uri[] baseAddresses) : base(servicetype, baseAddresses)
        {
            this.Opening += MyCustomServiceHost_Opening;
            if (baseAddresses != null)
            {
                this.baseAddresses = baseAddresses;
            }
        }

        private void MyCustomServiceHost_Opening(object sender, EventArgs e)
        {
            //NOTE - If behavior is custom...
            //MyCustomBehavior behavior = this.Description.Behaviors.Find<MyCustomBehavior>();
            //if (behavior != null)
            //{
            //    this.Description.Behaviors.Add(behavior);
            //}
            
            //NOTE - Standard mex behavior...
            ServiceMetadataBehavior mexBehavior = this.Description.Behaviors.Find<ServiceMetadataBehavior>();
            if (mexBehavior == null)
            {
                mexBehavior = new ServiceMetadataBehavior();
                mexBehavior.HttpGetEnabled = true;
                this.Description.Behaviors.Add(mexBehavior);
            }
        }

        protected override void ApplyConfiguration()
        {
            base.ApplyConfiguration();

            //Add your custom config here...
            foreach (Uri baseAddress in this.baseAddresses)
            {
                if (baseAddress.Scheme == Uri.UriSchemeHttp)
                {
                    this.AddServiceEndpoint(ServiceMetadataBehavior.MexContractName,
                                            MetadataExchangeBindings.CreateMexHttpBinding(),
                                            "mex");

                }
                else if (baseAddress.Scheme == Uri.UriSchemeHttps)
                {
                    this.AddServiceEndpoint(ServiceMetadataBehavior.MexContractName,
                                            MetadataExchangeBindings.CreateMexHttpsBinding(),
                                            "mex");
                }
                else if (baseAddress.Scheme == Uri.UriSchemeNetPipe)
                {
                    this.AddServiceEndpoint(ServiceMetadataBehavior.MexContractName,
                                            MetadataExchangeBindings.CreateMexNamedPipeBinding(),
                                            "mex");

                }
                else if (baseAddress.Scheme == Uri.UriSchemeNetTcp)
                {
                    this.AddServiceEndpoint(ServiceMetadataBehavior.MexContractName,
                                            MetadataExchangeBindings.CreateMexTcpBinding(),
                                            "mex");
                }
            }
        }

        /// <summary>
        /// [Copyright 2025 on all intellectual property by [Damien Wallace Eagles] eternally whereever it goes no matter what - - - - ]
        /// </summary>
        internal class MyCustomBehavior : IServiceBehavior
        {
            void IServiceBehavior.AddBindingParameters(ServiceDescription serviceDescription, ServiceHostBase serviceHostBase, Collection<ServiceEndpoint> endpoints, BindingParameterCollection bindingParameters)
            {
                //throw new NotImplementedException();
            }

            void IServiceBehavior.ApplyDispatchBehavior(ServiceDescription serviceDescription, ServiceHostBase serviceHostBase)
            {
                //throw new NotImplementedException();
            }

            void IServiceBehavior.Validate(ServiceDescription serviceDescription, ServiceHostBase serviceHostBase)
            {
                //throw new NotImplementedException();
            }
        }

    }
}