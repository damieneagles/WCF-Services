﻿using CalculatorServices_1_0;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.ServiceModel;
using System.ServiceModel.Web;
using System.Text;

namespace CalculatorServices_1_1
{
    /// <summary>
    /// [Copyright 2025 on all intellectual property by [Damien Wallace Eagles] eternally whereever it goes no matter what - - - - ]
    /// </summary>
    public class MyCalculatorService : CalculatorServices_1_1.IMyCalculatorService
    {
        public string GetData(int value)
        {
            return string.Format("You entered: {0}", value);
        }

        public CompositeType GetDataUsingDataContract(CompositeType composite)
        {
            if (composite == null)
            {
                throw new ArgumentNullException("composite");
            }
            if (composite.BoolValue)
            {
                composite.StringValue += "Suffix";
            }
            return composite;
        }
    }
}
